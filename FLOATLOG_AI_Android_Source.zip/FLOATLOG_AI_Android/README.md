# FLOATLOG AI — Android prototype source

## Current status
This is an Android Studio project scaffold for the Samsung Galaxy S24 Ultra. It opens the rear camera and continuously receives CameraX analysis frames. It does **not** yet contain a trained floating-log model, object detection, GPS target positioning, or alert logic. The app explicitly reports that the model is not installed rather than inventing detections.

A genuine log detector cannot be trained from the project specification alone. It needs labeled photos/video from the intended operating environment and independent sea-trial validation.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Connect the S24 Ultra with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have an Android SDK or a usable Gradle installation, so no APK was compiled here.

## Model integration still required
- Collect video from the banca at measured distances (20, 40, 60, 80, 100 m).
- Extract representative frames and annotate visible log bounding boxes.
- Split train/validation/test by recording session, not adjacent frames.
- Train a one-class detector (`floating_log`) using a suitable YOLO model.
- Export a compatible LiteRT/TFLite model and place it at `app/src/main/assets/floatlog.tflite`.
- Implement preprocessing, model invocation, output decoding, non-maximum suppression, and overlay rendering in the analyzer.
- Validate precision, recall, false alarms/hour, latency, and detection probability by distance and sea state.

## Safety and accuracy
A phone camera cannot see through seawater or darkness. 100 m detection of a 3–5 m log is not guaranteed; it depends on log orientation, visible freeboard, lighting, haze, waves, camera selection, stabilization, and pixel resolution. Do not rely on this prototype as a collision-avoidance system. Maintain a lookout and safe speed.
