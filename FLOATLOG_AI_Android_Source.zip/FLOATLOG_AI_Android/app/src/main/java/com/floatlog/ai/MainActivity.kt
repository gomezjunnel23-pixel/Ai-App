package com.floatlog.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var frameCount: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val frames = AtomicLong(0)
    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else status.text = "Camera permission required"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            // Location is optional in this prototype; request separately when GPS logging is added.
        }
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else permissions.launch(needed.toTypedArray())
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 12)
        }
        val title = TextView(this).apply {
            text = "FLOATLOG AI"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply {
            text = "STARTING CAMERA"
            textSize = 13f
            setTextColor(0xFFFFC857.toInt())
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(status)
        root.addView(header)

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 10, 18, 14)
        }
        frameCount = TextView(this).apply {
            text = "Camera frames: 0"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val notice = TextView(this).apply {
            text = "AI MODEL NOT INSTALLED — live camera preview only. No log detections are being made."
            textSize = 13f
            setTextColor(0xFFFFC857.toInt())
            setPadding(0, 6, 0, 0)
        }
        footer.addView(frameCount)
        footer.addView(notice)
        root.addView(footer)
        setContentView(root)
    }

    private fun startCamera() {
        status.text = "CAMERA READY"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image ->
                frames.incrementAndGet()
                runOnUiThread {
                    frameCount.text = "Camera frames: ${frames.get()}"
                }
                // TODO: Convert ImageProxy to model input and call the trained FLOATLOG detector.
                // This build deliberately does not fabricate detections without a validated model.
                image.close()
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
            } catch (e: Exception) {
                status.text = "CAMERA ERROR"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
