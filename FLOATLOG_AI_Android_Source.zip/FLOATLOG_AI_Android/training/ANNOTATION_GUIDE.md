# Annotation guide

Class: `floating_log` (class id 0).

Draw a tight bounding box around the visible portion of each floating tree trunk. Include partially submerged trunks only when a visible portion can be confidently identified. Do not label wakes, foam, wave crests, reflections, boats, or generic debris as logs.

Capture hard negatives: wave crests, foam, dark water patches, floating seaweed, driftwood fragments, buoys, boats, and shadows.

Record metadata for each clip/frame: estimated range, log length (if known), sea state, weather, time of day, camera zoom/lens, camera orientation, and whether the log is partially submerged.

Split data by entire recording session/clip to prevent near-duplicate frames appearing in both training and test sets.
