# Training starter. Requires a compatible Ultralytics installation and a CUDA-capable GPU for practical training.
from ultralytics import YOLO

model = YOLO("yolo26n.pt")
model.train(
    data="data.yaml",
    epochs=150,
    imgsz=960,
    batch=8,       # reduce if GPU memory is limited
    patience=30,
    project="runs/floatlog",
    name="floating_log_v1",
)
metrics = model.val(data="data.yaml", split="test")
print(metrics)
# Export format/runtime compatibility must be verified against the Android inference implementation.
best = YOLO("runs/floatlog/floating_log_v1/weights/best.pt")
best.export(format="tflite", imgsz=640)
